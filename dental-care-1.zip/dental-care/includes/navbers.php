<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Village Dental - Animated Navbar</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(to bottom right, #e0f2fe, #ffffff);
      min-height: 100vh;
    }

    nav {
      position: sticky;
      top: 0;
      z-index: 999;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 6%;
      background: rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(20px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
      border-radius: 0 0 20px 20px;
      transition: 0.4s ease;
    }

    .logo {
      font-size: 1.8rem;
      font-weight: 700;
      color: #1e3a8a;
      text-decoration: none;
      letter-spacing: 1px;
    }

    .nav-menu {
      display: flex;
      align-items: center;
      gap: 2.5rem;
    }

    .nav-links {
      display: flex;
      list-style: none;
      gap: 2rem;
    }

    .nav-links li {
      position: relative;
    }

    .nav-links a {
      text-decoration: none;
      color: #1f2937;
      font-weight: 600;
      font-size: 1rem;
      transition: color 0.3s ease;
      position: relative;
    }

    .nav-links a::after {
      content: '';
      position: absolute;
      left: 0;
      bottom: -5px;
      width: 100%;
      height: 2px;
      background-color: #2563eb;
      transform: scaleX(0);
      transform-origin: left;
      transition: transform 0.3s ease;
    }

    .nav-links a:hover::after {
      transform: scaleX(1);
    }

    .dropdown,
    .submenu {
      position: absolute;
      top: 100%;
      left: 0;
      min-width: 200px;
      background-color: #ffffffee;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
      opacity: 0;
      visibility: hidden;
      transform: translateY(20px) scale(0.95);
      transition: all 0.3s ease;
      padding: 0.5rem 0;
      z-index: 999;
    }

    .dropdown li {
      list-style: none;
    }

    .dropdown a {
      padding: 0.7rem 1.2rem;
      display: block;
      color: #333;
      font-size: 0.95rem;
      border-left: 3px solid transparent;
      transition: 0.3s;
    }

    .dropdown a:hover {
      background: #e0edff;
      border-left: 3px solid #2563eb;
      color: #1e40af;
    }

    .submenu {
      left: 100%;
      top: 0;
      transform: translateX(10px) scale(0.95);
    }

    .nav-links li:hover > .dropdown {
      opacity: 1;
      visibility: visible;
      transform: translateY(0px) scale(1);
    }

    .dropdown li:hover > .submenu {
      opacity: 1;
      visibility: visible;
      transform: translateX(0px) scale(1);
    }

    .contact-btns {
      display: flex;
      align-items: center;
      gap: 1.5rem;
    }

    .phone {
      font-weight: 600;
      color: #1f2937;
      font-size: 0.95rem;
      text-decoration: none;
    }

    .book-btn {
      padding: 0.5rem 1.4rem;
      background: linear-gradient(to right, #4f46e5, #3b82f6);
      color: white;
      border: none;
      border-radius: 999px;
      font-weight: 600;
      cursor: pointer;
      transition: 0.3s ease;
    }

    .book-btn:hover {
      background: linear-gradient(to right, #3b82f6, #1e40af);
      transform: translateY(-1px) scale(1.02);
    }

    .hamburger {
      display: none;
      flex-direction: column;
      gap: 6px;
      cursor: pointer;
      z-index: 1001;
    }

    .hamburger span {
      width: 28px;
      height: 3px;
      background: #1f2937;
      border-radius: 4px;
      transition: 0.4s ease;
    }

    .hamburger.open span:nth-child(1) {
      transform: rotate(45deg) translate(5px, 5px);
    }

    .hamburger.open span:nth-child(2) {
      opacity: 0;
    }

    .hamburger.open span:nth-child(3) {
      transform: rotate(-45deg) translate(5px, -5px);
    }

    /* Mobile Styles */
    @media (max-width: 992px) {
      .nav-menu {
        position: fixed;
        top: 0;
        right: -100%;
        flex-direction: column;
        background: rgba(255, 255, 255, 0.95);
        width: 80%;
        height: 100vh;
        padding: 6rem 2rem;
        gap: 2rem;
        transition: right 0.5s ease-in-out;
        box-shadow: -10px 0 20px rgba(0, 0, 0, 0.08);
        opacity: 0;
      }

      .nav-menu.active {
        right: 0;
        opacity: 1;
      }

      .nav-links {
        flex-direction: column;
        gap: 1.5rem;
      }

      .dropdown,
      .submenu {
        all: unset;
        display: none;
      }

      .nav-links li:active .dropdown {
        display: block;
        margin-top: 0.4rem;
      }

      .contact-btns {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      }

      .hamburger {
        display: flex;
      }
    }
  </style>
</head>
<body>

  <nav>
    <a href="#" class="logo">VILLAGE DENTAL</a>

    <div class="hamburger" onclick="toggleMenu(this)">
      <span></span>
      <span></span>
      <span></span>
    </div>

    <div class="nav-menu" id="navMenu">
      <ul class="nav-links">
        <li>
          <a href="#">ABOUT</a>
          <ul class="dropdown">
            <li><a href="#">MEET THE DOCTOR</a></li>
            <li><a href="#">BEFORE AND AFTER</a></li>
            <li><a href="#">CAREERS</a></li>
            <li><a href="#">FAQ</a></li>
            <li><a href="#">FEE-FOR-SERVICE DENTIST</a></li>
            <li><a href="#">DENTAL TECHNOLOGY</a></li>
            <li><a href="#">BLOG</a></li>
            <li><a href="#">IT TAKES A VILLAGE</a></li>
          </ul>
        </li>

        <li>
          <a href="#">SERVICES</a>
          <ul class="dropdown">
            <li>
              <a href="#">GENERAL</a>
              <ul class="submenu">
                <li><a href="#">BOTOX</a></li>
                <li><a href="#">CLEANINGS & EXAMS</a></li>
                <li><a href="#">EMERGENCY CARE</a></li>
                <li><a href="#">CROWNS</a></li>
                <li><a href="#">GUM THERAPY</a></li>
                <li><a href="#">DENTAL FILLINGS</a></li>
                <li><a href="#">DENTURES</a></li>
                <li><a href="#">FAMILY DENTISTRY</a></li>
              </ul>
            </li>
            <li>
              <a href="#">COSMETIC</a>
              <ul class="submenu">
                <li><a href="#">INVISALIGN</a></li>
                <li><a href="#">BOTOX</a></li>
                <li><a href="#">TEETH WHITENING</a></li>
                <li><a href="#">BONDING</a></li>
                <li><a href="#">VENEERS</a></li>
                <li><a href="#">SMILE MOKEOVER</a></li>
              </ul>
            </li>
            <li>
              <a href="#">SURGICAL</a>
              <ul class="submenu">
                <li><a href="#">IMPLANTS</a></li>
                <li><a href="#">EXTRACTIONS</a></li>
                <li><a href="#">ROOT CANAL</a></li>
                <li><a href="#">BONE GRAFTS</a></li>
                <li><a href="#">IMPLANT-SUPPORTED DENTURES</a></li>
                <li><a href="#">BRIDGES</a></li>
              </ul>
            </li>
            <li>
              <a href="#">PROBLEMS WE TREAT</a>
              <ul class="submenu">
                <li><a href="#">CHIPPED OR CRACKED TEETH</a></li>
                <li><a href="#">WISDOM TOOTH PAIN</a></li>
                <li><a href="#">MISSING TOOTH</a></li>
                <li><a href="#">TOOTHACHE</a></li>
                <li><a href="#">TEETH GRINDING</a></li>
                <li><a href="#">STAINED TEETH</a></li>
                <li><a href="#">CROOKED TEETH</a></li>
                <li><a href="#">BLEEDING GUMS</a></li>
                <li><a href="#">BAD BREATH</a></li>
              </ul>
            </li>
          </ul>
        </li>

        <li>
          <a href="#">WARRANTY</a>
          <ul class="dropdown">
            <li><a href="#">Our Guarantee</a></li>
            <li><a href="#">Coverage Details</a></li>
          </ul>
        </li>

        <li>
          <a href="#">NEW PATIENTS</a>
          <ul class="dropdown">
            <li><a href="#">First Visit</a></li>
            <li><a href="#">Insurance Info</a></li>
          </ul>
        </li>
        <li>
          <a href="#">DENTIEST PROFILE</a>
          <ul class="dropdown">
            <li><a href="dentists.php">First Visit</a></li>
            <li><a href="#">Insurance Info</a></li>
          </ul>
        </li>
      </ul>

      <div class="contact-btns">
        <!-- <a href="tel:3032207662" class="phone">(303) 220-7662</a> -->
        <a href="login-system/login.php">
        <button class="book-btn">BOOK ONLINE</button>
        </a>
        
      </div>
    </div>
  </nav>

  <script>
    function toggleMenu(btn) {
      const navMenu = document.getElementById('navMenu');
      navMenu.classList.toggle('active');
      btn.classList.toggle('open');
    }
  </script>
</body>
</html>
