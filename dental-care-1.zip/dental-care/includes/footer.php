<style>
  /* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  
  body {
    font-family: 'Segoe UI', sans-serif;
  }
  
  
  
  


  /* footer */
  .footer {
    background-color: #2e6c80;
    color: white;
    padding: 40px 60px;
    font-family: 'Segoe UI', sans-serif;
  }
  
  .footer-content {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 40px;
    margin-bottom: 30px;
  }
  
  .footer-col h3 {
    font-size: 20px;
    margin-bottom: 15px;
  }
  
  .footer-col ul {
    list-style: none;
    padding: 0;
  }
  
  .footer-col ul li {
    margin-bottom: 10px;
    font-size: 14px;
  }
  
  .footer-col a {
    color: white;
    text-decoration: none;
  }
  
  .social-icons a img {
    width: 25px;
    margin-right: 10px;
  }
  
  .btn-yellow.small {
    background-color: rgb(52, 52, 240);
    color: #fff;
    padding: 10px 20px;
    display: inline-block;
    margin-top: 10px;
    font-weight: bold;
    text-decoration: none;
  }
  
  .footer-bottom {
    border-top: 1px solid #ffffff44;
    padding-top: 20px;
    font-size: 14px;
    text-align: center;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
  }
/* Footer link hover */
.footer-col a:hover {
    text-decoration: underline;
    color: rgb(52, 52, 240);
    transition: all 0.3s ease;
  }
  
  /* Social icons hover */
  .social-icons a img {
    transition: transform 0.3s ease;
  }
  
  .social-icons a:hover img {
    transform: scale(1.2);
    filter: brightness(1.3);
  }
  
  /* Button hover */
  .btn-yellow:hover {
    background-color: #fff; 
    color: rgb(52, 52, 240);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
  }

  

  
  /* Email & phone hover */
  .footer-col p a:hover {
    color: rgb(52, 52, 240);
    text-decoration: underline;
    transition: 0.3s;
  }
    
  
</style>
<footer class="footer">
  <div class="footer-content">
    <div class="footer-col">
      <h3>Social</h3>
      <div class="social-icons">
        <a href="#"><img src="assets/facebook.png" alt="Facebook" /></a>
        <a href="#"><img src="assets/instagram.png" alt="Instagram" /></a>
      </div>
    </div>

    <div class="footer-col">
      <h3>Services</h3>
      <ul>
        <li>General</li>
        <li>Cosmetic</li>
        <li>Surgical</li>
      </ul>
    </div>

    <div class="footer-col">
      <h3>Our Office</h3>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Warranty</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">New Patients</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <a href="#" class="btn-yellow small">PAY ONLINE</a>

    </div>

    <div class="footer-col">
      <h3>Contact Us</h3>
      <p>5670 Greenwood Plaza Blvd<br>
      Suite 404, Greenwood Village,<br>
      CO 80111</p>
      <p>(720) 730-9140</p>
      <p><a href="mailto:info@villagedentaldtc.com">info@villagedentaldtc.com</a></p>
    </div>
  </div>

  <div class="footer-bottom">
    <p>© Village Dental 2025 | Privacy Policy | Accessibility Statement</p>
    <p>Dental Website by :Delmain</p>
  </div>
</footer>
