
    function toggleMenu(btn) {
      const navMenu = document.getElementById('navMenu');
      navMenu.classList.toggle('active');
      btn.classList.toggle('open');
    }
