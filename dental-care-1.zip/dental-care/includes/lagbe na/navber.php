<header class="navbar">
  <div class="logo">VILLAGE DENTAL</div>
  <ul class="nav-links">
    <li><a href="#">ABOUT</a></li>
    <li><a href="#">SERVICES</a></li>
    <li><a href="#">WARRANTY</a></li>
    <li><a href="#">NEW PATIENTS</a></li>
    <li class="phone">(303) 220-7662</li>
    <li><a href="login-system/login.php" class="btn">BOOK ONLINE</a></li>
  </ul>
</header>
