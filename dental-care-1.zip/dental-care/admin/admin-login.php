<?php
session_start();
include '../login-system/db.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        if ($admin['password'] === $password) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_email'] = $email;
            header("Location: dashboard.php");
            exit;
        } else {
            echo "❌ Incorrect password.";
        }
    } else {
        echo "❌ Admin not found.";
    }
}
?>

<!-- Keep your PHP logic same -->

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: 'Quicksand', sans-serif;
      background: linear-gradient(135deg, #667eea, #764ba2);
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .login-container {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      padding: 40px 30px;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
      width: 100%;
      max-width: 400px;
      position: relative;
      overflow: hidden;
    }

    .login-container::before {
      content: "";
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: conic-gradient(from 90deg at 50% 50%, #ff6ec4, #7873f5, #47caff, #ff6ec4);
      animation: rotate 6s linear infinite;
      z-index: -1;
      opacity: 0.2;
    }

    @keyframes rotate {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    h2 {
      text-align: center;
      margin-bottom: 25px;
      background: linear-gradient(to right, #f9d423, #ff4e50);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      font-size: 28px;
      font-weight: 700;
    }

    .input-field {
      position: relative;
      margin-bottom: 20px;
    }

    .input-field input {
      width: 100%;
      padding: 14px 45px 14px 15px;
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.1);
      color: #ffffff;
      font-size: 15px;
      transition: 0.3s;
    }

    .input-field input::placeholder {
      color: #ddd;
    }

    .input-field input:focus {
      border-color: #00ffe1;
      background: rgba(255, 255, 255, 0.2);
    }

    .toggle-password {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      font-size: 18px;
      color: #fff;
      transition: 0.3s ease;
    }

    .toggle-password:hover {
      transform: translateY(-50%) scale(1.2);
      color: #00ffe1;
    }

    button {
      width: 100%;
      padding: 14px;
      background: linear-gradient(to right, #ff6ec4, #7873f5);
      color: white;
      border: none;
      border-radius: 12px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
    }

    button:hover {
      background: linear-gradient(to right, #47caff, #ff6ec4);
      transform: scale(1.02);
    }

    .extra-links {
      text-align: center;
      margin-top: 15px;
    }

    .extra-links a {
      color: #ffdde1;
      text-decoration: none;
      font-size: 14px;
      text-shadow: 0 0 3px rgba(255, 255, 255, 0.2);
    }

    .extra-links a:hover {
      color: #fff;
      text-decoration: underline;
    }

    .error {
      color: #ffcdd2;
      background: rgba(255, 0, 0, 0.1);
      border-radius: 8px;
      padding: 8px;
      text-align: center;
      margin-bottom: 15px;
      font-weight: bold;
      letter-spacing: 0.5px;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Admin Login</h2>
    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
    <form method="POST">
      <div class="input-field">
        <input type="email" name="email" placeholder="Email" required>
      </div>
      <div class="input-field">
        <input type="password" name="password" id="password" placeholder="Password" required>
        <span class="toggle-password" onclick="togglePassword()" id="toggleIcon">👁️</span>
      </div>
      <button type="submit">Login</button>
      <div class="extra-links">
        <a href="forgot-password.php">Forgot Password?</a>
      </div>
    </form>
  </div>

  <script>
    function togglePassword() {
      const passwordInput = document.getElementById("password");
      const toggleIcon = document.getElementById("toggleIcon");
      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        toggleIcon.textContent = "🙈";
      } else {
        passwordInput.type = "password";
        toggleIcon.textContent = "👁️";
      }
    }
  </script>
</body>
</html>
