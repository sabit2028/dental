<?php
include 'includes/admin-navbar.php';
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin-login.php");
    exit;
}

include '../login-system/db.php';

// Handle Confirm/Reject
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $status = ($_GET['action'] == 'confirm') ? 'Confirmed' : 'Rejected';

    $stmt = $conn->prepare("UPDATE appointments SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Appointments</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f4f4;
            padding: 30px;
        }
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .status {
            font-weight: bold;
        }
        .btn {
            padding: 5px 12px;
            margin-right: 5px;
            text-decoration: none;
            color: white;
            border-radius: 5px;
        }
        .btn-confirm {
            background-color: #28a745;
        }
        .btn-reject {
            background-color: #dc3545;
        }
    </style>
</head>
<body>

<h2>All Appointments</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Patient</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Service</th>
        <th>Dentist</th>
        <th>Date</th>
        <th>Time</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

    <?php
    $sql = "SELECT a.*, d.name AS dentist_name FROM appointments a 
            LEFT JOIN dentists d ON a.dentist_id = d.id 
            ORDER BY a.id DESC";
    $result = $conn->query($sql);

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['patient_name']}</td>
            <td>{$row['email']}</td>
            <td>{$row['phone']}</td>
            <td>{$row['service']}</td>
            <td>{$row['dentist_name']}</td>
            <td>{$row['date']}</td>
            <td>{$row['time']}</td>
            <td class='status'>{$row['status']}</td>
            <td>
                <a href='?action=confirm&id={$row['id']}' class='btn btn-confirm'>Confirm</a>
                <a href='?action=reject&id={$row['id']}' class='btn btn-reject'>Reject</a>
            </td>
        </tr>";
    }
    ?>
</table>

</body>
</html>
