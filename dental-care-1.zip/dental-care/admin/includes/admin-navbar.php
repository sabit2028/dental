<!-- admin/includes/admin-navbar.php -->

<style>
    .admin-navbar {
        background: #0f172a;
        padding: 15px 30px;
        display: flex;
        gap: 20px;
        align-items: center;
    }
    .admin-navbar a {
        color: white;
        text-decoration: none;
        font-weight: 500;
        transition: 0.3s ease;
    }
    .admin-navbar a:hover {
        color: #38bdf8;
    }
</style>

<div class="admin-navbar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="manage-dentists.php">🦷 Manage Dentists</a>
    <a href="appointments.php">📅 View Appointments</a>
</div>
