<?php
include 'includes/admin-navbar.php';
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin-login.php");
    exit;
}

include '../login-system/db.php';

// Handle dentist insertion
if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $bio = $_POST['bio'];

    $imageName = time() . '_' . $_FILES['image']['name'];
    $tmpName = $_FILES['image']['tmp_name'];

    // Upload path relative to admin directory
    $uploadDir = '../uploads/';
    $uploadPath = $uploadDir . $imageName;

    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    move_uploaded_file($tmpName, $uploadPath);

    // Save path relative to project root for frontend display
    $dbPath = 'uploads/' . $imageName;

    $stmt = $conn->prepare("INSERT INTO dentists (name, bio, image) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $bio, $dbPath);
    $stmt->execute();
}

// Handle deletion
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM dentists WHERE id=$id");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Dentists</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial;
            background: #f5f5f5;
            padding: 30px;
        }
        .form-box, .table-box {
            background: white;
            padding: 25px;
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        input, textarea {
            width: 100%;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        img {
            width: 60px;
            height: 60px;
            border-radius: 5px;
            object-fit: cover;
        }
        .btn-sm {
            padding: 5px 10px;
        }
    </style>
</head>
<body>

<div class="form-box">
    <h2>Add New Dentist</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Dentist Name" required>
        <textarea name="bio" placeholder="Short Bio" required></textarea>
        <input type="file" name="image" required>
        <button type="submit" name="add">Add Dentist</button>
    </form>
</div>

<div class="table-box">
    <h2>All Dentists</h2>
    <table>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Bio</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
        <?php
        $result = $conn->query("SELECT * FROM dentists");
        while ($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= $row['name']; ?></td>
            <td><?= $row['bio']; ?></td>
            <td><img src="../<?= $row['image']; ?>" alt="Dentist"></td>
            <td>
                <a href="edit-dentist.php?id=<?= $row['id']; ?>" class="btn btn-outline-primary btn-sm me-2">
                    ✏️ Edit
                </a>
                <a href="?delete=<?= $row['id']; ?>" class="btn btn-outline-danger btn-sm"
                   onclick="return confirm('Are you sure you want to delete this dentist?')">
                    🗑️ Delete
                </a>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>

</body>
</html>
