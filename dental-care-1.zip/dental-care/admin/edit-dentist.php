<?php
include 'includes/admin-navbar.php';
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin-login.php");
    exit;
}

include '../login-system/db.php';

$id = $_GET['id'];

// Fetch current dentist info
$result = $conn->query("SELECT * FROM dentists WHERE id = $id");
$row = $result->fetch_assoc();

if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $bio = $_POST['bio'];
    $imagePath = $row['image']; // default: old image path

    if (!empty($_FILES['image']['name'])) {
        // New image uploaded
        $imageName = time() . '_' . $_FILES['image']['name'];
        $tmpName = $_FILES['image']['tmp_name'];
        $uploadDir = '../uploads/';
        $uploadPath = $uploadDir . $imageName;

        // Create upload dir if not exists
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        move_uploaded_file($tmpName, $uploadPath);
        $imagePath = 'uploads/' . $imageName; // path saved in DB
    }

    $stmt = $conn->prepare("UPDATE dentists SET name=?, bio=?, image=? WHERE id=?");
    $stmt->bind_param("sssi", $name, $bio, $imagePath, $id);
    $stmt->execute();

    header("Location: manage-dentists.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Dentist</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Arial; background: #f5f5f5; padding: 30px; }
        .edit-box {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: auto;
        }
        input, textarea {
            width: 100%;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        img {
            width: 100px;
            height: 100px;
            border-radius: 6px;
            object-fit: cover;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="edit-box">
    <h2>Edit Dentist</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="name" value="<?= $row['name']; ?>" required>
        <textarea name="bio" required><?= $row['bio']; ?></textarea>

        <label>Current Image:</label><br>
        <img src="../<?= $row['image']; ?>" alt="Dentist"><br>

        <label>Change Image (optional):</label>
        <input type="file" name="image">

        <button type="submit" name="update" class="btn btn-success mt-3">Update Dentist</button>
    </form>
</div>

</body>
</html>
