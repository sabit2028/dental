<?php

session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin-login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial;
            background: #f5f5f5;
            padding: 40px;
        }
        .container {
            background: white;
            max-width: 600px;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        h2 {
            color: #333;
            text-align: center;
        }
        .nav {
            margin-top: 30px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        a {
            padding: 12px;
            background: #007bff;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 6px;
            transition: background 0.3s;
        }
        a:hover {
            background: #0056b3;
        }
        .logout {
            background: crimson;
        }
        .logout:hover {
            background: darkred;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Welcome Admin 👨‍⚕️</h2>
    <div class="nav">
        <a href="manage-dentists.php">🦷 Manage Dentists</a>
        <a href="appointments.php">📅 View Appointments</a>
        <a href="logout.php" class="logout">🚪 Logout</a>
    </div>
</div>

</body>
</html>
