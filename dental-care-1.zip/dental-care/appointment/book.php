<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Appointment Booking</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      font-family: 'Poppins', sans-serif;
      background: #f0f4f8;
      color: #333;
    }

    .container {
      max-width: 700px;
      margin: 50px auto;
      background: #fff;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
    }

    h2 {
      font-size: 26px;
      font-weight: 600;
      margin-bottom: 20px;
      color: #222;
    }

    label {
      font-weight: 500;
      margin-top: 25px;
      display: block;
    }

    .field-group {
      display: flex;
      gap: 15px;
      margin-top: 10px;
      flex-wrap: wrap;
    }

    input[type="text"] {
      flex: 1;
      padding: 12px 14px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 10px;
      transition: border-color 0.3s;
    }

    input[type="text"]:focus {
      border-color: #007bff;
      outline: none;
    }

    input.error {
      border-color: red;
    }

    .checkbox-container {
      margin-top: 12px;
    }

    .checkbox-container input {
      margin-right: 8px;
    }

    .btn-group {
      display: flex;
      gap: 15px;
      flex-wrap: wrap;
      margin-top: 15px;
    }

    .btn {
      flex: 1;
      min-width: 45%;
      padding: 12px;
      font-size: 16px;
      text-align: center;
      background: #f9f9f9;
      border: 1.5px solid #ccc;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.3s ease;
      user-select: none;
    }

    .btn:hover {
      background-color: #eaf1ff;
      border-color: #007bff;
    }

    .btn.selected {
      background-color: #eaf1ff;
      border: 2px solid #007bff;
      color: #007bff;
      font-weight: 600;
    }

    .navigation {
      margin-top: 30px;
      display: flex;
      justify-content: space-between;
    }

    .nav-btn {
      padding: 12px 24px;
      font-size: 16px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .nav-btn:hover {
      background: #005ecb;
    }

    .step {
      display: none;
    }

    .step.active {
      display: block;
    }

    .provider-card {
      display: inline-block;
      width: 47%;
      border: 1px solid #ccc;
      padding: 14px;
      margin: 10px 1%;
      border-radius: 12px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .provider-card:hover {
      border-color: #007bff;
    }

    .provider-card.selected {
      border: 2px solid #007bff;
      background: #eaf1ff;
      font-weight: 600;
    }

    .error-message {
      color: red;
      font-size: 14px;
      margin-top: 5px;
    }

    @media (max-width: 600px) {
      .btn {
        min-width: 100%;
      }
      .provider-card {
        width: 100%;
      }
      .navigation {
        flex-direction: column;
        gap: 15px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <form id="appointmentForm">
      <!-- Step 1 -->
      <div class="step active" id="step1">
        <h2>Hi, Welcome to Village Dental - CO</h2>
        <label>Who is this appointment for?</label>
        <div class="field-group">
          <input type="text" id="firstName" placeholder="First Name" required />
          <input type="text" id="lastName" placeholder="Last Name" required />
        </div>
        <div class="checkbox-container">
          <input type="checkbox" id="forSomeoneElse" />
          <label for="forSomeoneElse" style="display: inline">I'm booking for someone else</label>
        </div>
        <label>Have you visited us before?</label>
        <div class="btn-group" id="patientTypeGroup">
          <div class="btn" onclick="selectBtn(this, 'patientType', 'new')">New Patient</div>
          <div class="btn" onclick="selectBtn(this, 'patientType', 'returning')">Returning Patient</div>
        </div>
        <div class="navigation">
          <button type="button" class="nav-btn" onclick="validateStep1()">Next</button>
        </div>
      </div>

      <!-- Step 2 -->
      <div class="step" id="step2">
        <h2>We are excited to meet you.</h2>
        <label>What would you like to come in for?</label>
        <div class="btn-group" id="serviceGroup">
          <div class="btn" onclick="selectBtn(this, 'service', 'Botox')">Botox</div>
          <div class="btn" onclick="selectBtn(this, 'service', 'Dental Implant')">Dental Implant Consult</div>
          <div class="btn" onclick="selectBtn(this, 'service', 'Invisalign')">Invisalign Consult</div>
          <div class="btn" onclick="selectBtn(this, 'service', 'Cleaning 14')">Cleaning & Exam (14 & under)</div>
          <div class="btn" onclick="selectBtn(this, 'service', 'Cleaning Adult')">Cleaning & Exam - Adult</div>
          <div class="btn" onclick="selectBtn(this, 'service', 'Emergency')">Emergency / Tooth Pain</div>
        </div>
        <div class="navigation">
          <button type="button" class="nav-btn" onclick="prevStep(1)">Back</button>
          <button type="button" class="nav-btn" onclick="validateStep2()">Next</button>
        </div>
      </div>

      <!-- Step 3 -->
      <div class="step" id="step3">
        <h2>Which provider would you like to see?</h2>
        <div id="providers">
          <div class="provider-card" onclick="selectProvider(this)">Dr. Ana Ruzo, DDS</div>
          <div class="provider-card" onclick="selectProvider(this)">Dr. Steven Zervas, DDS</div>
        </div>
        <div class="navigation">
          <button type="button" class="nav-btn" onclick="prevStep(2)">Back</button>
          <button type="button" class="nav-btn" onclick="validateStep3()">Next</button>
        </div>
      </div>
    </form>
  </div>

  <script>
    let currentStep = 1;
    let selectedPatientType = '';
    let selectedService = '';
    let selectedProvider = '';

    function nextStep(step) {
      document.querySelector(`#step${currentStep}`).classList.remove('active');
      currentStep = step;
      document.querySelector(`#step${currentStep}`).classList.add('active');
    }

    function prevStep(step) {
      document.querySelector(`#step${currentStep}`).classList.remove('active');
      currentStep = step;
      document.querySelector(`#step${currentStep}`).classList.add('active');
    }

    function selectBtn(el, groupName, value) {
      const group = el.parentElement;
      group.querySelectorAll('.btn').forEach(btn => btn.classList.remove('selected'));
      el.classList.add('selected');
      if (groupName === 'patientType') selectedPatientType = value;
      if (groupName === 'service') selectedService = value;
    }

    function selectProvider(el) {
      document.querySelectorAll('.provider-card').forEach(card => card.classList.remove('selected'));
      el.classList.add('selected');
      selectedProvider = el.textContent.trim();
    }

    function validateStep1() {
      const firstName = document.getElementById('firstName');
      const lastName = document.getElementById('lastName');

      let valid = true;

      [firstName, lastName].forEach(input => {
        if (!input.value.trim()) {
          input.classList.add('error');
          valid = false;
        } else {
          input.classList.remove('error');
        }
      });

      if (!selectedPatientType) {
        alert("Please select patient type.");
        return;
      }

      if (valid) {
        nextStep(2);
      }
    }

    function validateStep2() {
      if (!selectedService) {
        alert("Please select a service.");
        return;
      }
      nextStep(3);
    }

    function validateStep3() {
      if (!selectedProvider) {
        alert("Please select a provider.");
        return;
      }
      handleFinalStep();
    }

    function handleFinalStep() {
      alert(`Thank you! Your appointment request has been received. We'll contact you soon.`);
      // Optional: document.getElementById("appointmentForm").reset();
    }
  </script>
</body>
</html>
