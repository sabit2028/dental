<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dental Health Care</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/navbers.php'; ?>
    <!-- Hero Section -->
    <section class="hero">
    <video autoplay muted loop playsinline class="bg-video">
      <source src="assets/video/background.mp4" type="video/mp4">
      Your browser does not support HTML5 video.
    </video>

    <div class="overlay">
      <h4>TRUSTED DENVER TECH CENTER DENTISTS</h4>
      <h1>Exceptional care<br> for all ages</h1>
      <a href="login-system/login.php" class="btn-yellow">BOOK ONLINE</a>
      <p class="call-now">CALL (303) 220-7662</p>
    </div>
  </section>


    <!-- Footer -->

    <?php include('includes/footer.php');?>
    
    <script src="assets/js/script.js"></script>
</body>
</html>
