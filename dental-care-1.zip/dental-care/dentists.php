<?php
//include 'includes/navbers.php';
include 'login-system/db.php';

// Fetch all dentists
$result = $conn->query("SELECT * FROM dentists");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Our Dentists</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f9f9f9;
        }
        .dentist-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease-in-out;
        }
        .dentist-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
        }
        .dentist-image {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
            border: 4px solid #0dcaf0;
        }
        .btn-book {
            background-color: #0dcaf0;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            transition: 0.3s ease;
        }
        .btn-book:hover {
            background-color: #0bb5dc;
        }
        h2.section-title {
            text-align: center;
            margin: 40px 0 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h2 class="section-title">Meet Our Dentists 🦷</h2>

    <div class="row g-4">
        <?php while ($row = $result->fetch_assoc()) { ?>
            <div class="col-md-4">
                <div class="dentist-card text-center">
                    <img src="<?= $row['image']; ?>" class="dentist-image" alt="<?= $row['name']; ?>">
                    <h4 class="mt-2"><?= $row['name']; ?></h4>
                    <p><?= $row['bio']; ?></p>
                    <a href="book-appointment.php?dentist_id=<?= $row['id']; ?>" class="btn btn-book mt-2">📅 Book Appointment</a>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

</body>
</html>
