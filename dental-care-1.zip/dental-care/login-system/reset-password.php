<?php
include 'db.php';

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Step 1: Check if token is valid and not expired
    $stmt = $conn->prepare("SELECT * FROM users WHERE reset_token = ? AND token_expire > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $msg = '';

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $newPassword = $_POST['new_password'];
            $confirmPassword = $_POST['confirm_password'];

            // Step 2: Check password match
            if ($newPassword === $confirmPassword) {
                $hashed = password_hash($newPassword, PASSWORD_DEFAULT);

                // Step 3: Update password in DB
                $update = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, token_expire = NULL WHERE id = ?");
                $update->bind_param("si", $hashed, $user['id']);

                if ($update->execute()) {
                    $msg = "<p style='color: green;'>✅ Password reset successfully. <a href='login.php'>Login now</a></p>";
                } else {
                    $msg = "<p style='color: red;'>❌ Failed to update password. Try again.</p>";
                }
            } else {
                $msg = "<p style='color: red;'>❌ Passwords do not match.</p>";
            }
        }
    } else {
        echo "<p style='color: red;'>❌ Invalid or expired token.</p>";
        exit;
    }
} else {
    echo "<p style='color: red;'>❌ No token provided.</p>";
    exit;
}
?>

<!-- ✅ Reset Password HTML Form -->
<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <style>
        body {
            background: linear-gradient(to right, #74ebd5, #ACB6E5);
            font-family: 'Segoe UI', sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            width: 400px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #27ae60;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background-color: #219150;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Reset Your Password</h2>
        <?php if (isset($msg)) echo $msg; ?>
        <form method="POST">
            <input type="password" name="new_password" placeholder="New Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Update Password</button>
        </form>
    </div>
</body>
</html>
