<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name     = $_POST['name'];
  $email    = $_POST['email'];
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

  $check = $conn->query("SELECT * FROM users WHERE email='$email'");
  if ($check->num_rows > 0) {
    $message = "❌ Email already registered!";
  } else {
    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
    if ($conn->query($sql)) {
      $message = "✅ Registration successful. <a href='login.php'>Login now</a>";
    } else {
      $message = "❌ Error: " . $conn->error;
    }
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Register</title>
  <style>
    body {
      background: linear-gradient(120deg, #a1c4fd, #c2e9fb);
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .form-container {
      background: white;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      width: 350px;
      text-align: center;
    }

    .form-container h2 {
      margin-bottom: 20px;
      color: #333;
    }

    input {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 16px;
    }

    button {
      background-color: #2ecc71;
      color: white;
      border: none;
      padding: 10px 20px;
      margin-top: 10px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: 0.3s;
    }

    button:hover {
      background-color: #27ae60;
    }

    .message {
      margin-top: 15px;
      color: #d63031;
    }

    a {
      color: #0984e3;
      text-decoration: none;
      font-weight: 600;
    }

    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Create Account</h2>
    <form method="post">
      <input type="text" name="name" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email Address" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Register</button>
    </form>
    <?php if (isset($message)) echo "<div class='message'>$message</div>"; ?>
    <p style="margin-top: 10px;">Already have an account? <a href="login.php">Login here</a></p>
  </div>
</body>
</html>
