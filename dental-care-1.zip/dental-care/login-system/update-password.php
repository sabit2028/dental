<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $token = $_POST['token'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];

    if ($new !== $confirm) {
        die("❌ Passwords do not match.");
    }

    $hash = password_hash($new, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("UPDATE users SET password=?, reset_token=NULL, token_expire=NULL WHERE reset_token=?");
    $stmt->bind_param("ss", $hash, $token);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "✅ Password updated successfully. <a href='login.php'>Login now</a>";
    } else {
        echo "❌ Something went wrong.";
    }
}
?>
