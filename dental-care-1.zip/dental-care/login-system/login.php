<?php


include 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $email    = $_POST['email'];
  $password = $_POST['password'];

  $result = $conn->query("SELECT * FROM users WHERE email='$email'");

  if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
      $_SESSION['user'] = $user;
      header("Location: dashboard.php");
      exit();
    } else {
      $message = "❌ Wrong password!";
    }
  } else {
    $message = "❌ No user found!";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <style>
    body {
      background: linear-gradient(120deg, #fbc2eb, #a6c1ee);
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .form-container {
      background: white;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      width: 350px;
      text-align: center;
    }

    .form-container h2 {
      margin-bottom: 20px;
      color: #333;
    }

    input {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 16px;
    }

    button {
      background-color: #3498db;
      color: white;
      border: none;
      padding: 10px 20px;
      margin-top: 10px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: 0.3s;
    }

    button:hover {
      background-color: #2980b9;
    }

    .message {
      margin-top: 15px;
      color: #d63031;
    }

    a {
      color: #0984e3;
      text-decoration: none;
      font-weight: 600;
    }

    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="form-container">
    <h2>Login to Your Account</h2>
    <form method="post">
      <input type="email" name="email" placeholder="Email Address" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
    <?php if (isset($message)) echo "<div class='message'>$message</div>"; ?>
    <p style="margin-top: 10px;">Don't have an account? <a href="register.php">Register here</a></p>
    <p style="margin-top: 10px;">

  <a href="forgot.php" style="color:#e17055;">Forgot Password?</a>
</p>

  </div>

 
</body>
</html>
