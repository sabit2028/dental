<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set('Asia/Dhaka');

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
include 'db.php';

$message = ''; // Message holder

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $token = hash('sha512', bin2hex(random_bytes(16)));
    $expire = date("Y-m-d H:i:s", strtotime('+1 hour'));

    $stmt = $conn->prepare("UPDATE users SET reset_token=?, token_expire=? WHERE email=?");
    $stmt->bind_param("sss", $token, $expire, $email);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'hibrul.su@gmail.com';
                $mail->Password = 'vhtqqvkghsvtwqlx';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('hibrul.su@gmail.com', 'DentalCare Support');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Reset Your Password';
                $mail->Body = "Click here to reset your password: <br><br> 
                    <a href='http://localhost/project/dental-care/login-system/reset-password.php?token=$token'>Reset Password</a>";

                $mail->send();
                $message = "<p style='color: green;'>✅ Reset link sent to your email.</p>";
            } catch (Exception $e) {
                $message = "<p style='color: red;'>❌ Mail error: " . $mail->ErrorInfo . "</p>";
            }
        } else {
            $message = "<p style='color: red;'>❌ No matching email found.</p>";
        }
    } else {
        $message = "<p style='color: red;'>❌ Failed to update token.</p>";
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <style>
        body {
            background: linear-gradient(120deg, #ffecd2, #fcb69f);
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            width: 350px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        h3 {
            margin-bottom: 15px;
            text-align: center;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            font-size: 16px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        button {
            background: #27ae60;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background: #219150;
        }
        .message {
            margin-top: 15px;
            text-align: center;
            font-size: 15px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <form method="POST">
            <h3>Forgot Password?</h3>
            <input type="email" name="email" placeholder="Enter your email" required />
            <button type="submit">Send Reset Link</button>
        </form>
        <div class="message"><?php echo $message; ?></div>
    </div>
</body>
</html>
