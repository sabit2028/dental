// Just for future use: animation or effects
//console.log("Dental site loaded.");
